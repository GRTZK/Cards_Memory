﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Экзамен_Макеты
{
    /// <summary>
    /// Логика взаимодействия для Menu.xaml
    /// </summary>
    public partial class Menu : Window
    {
        public Menu()
        {
            InitializeComponent();
        }
        private void Butt1(object sender, RoutedEventArgs e)
        {
            MainWindow window2 = new MainWindow();
            window2.Show();
            this.Close();
        }
        private void Butt2(object sender, RoutedEventArgs e)
        {
            
            Setting window2 = new Setting();
            window2.Show();
        }
        private void Butt3(object sender, RoutedEventArgs e)
        {
            
            CountCard window2 = new CountCard();
            window2.Show();
            this.Close();
        }
        private void Butt4(object sender, RoutedEventArgs e)
        {
            Statistic window2 = new Statistic();
            window2.Show();
        }
    }
}
