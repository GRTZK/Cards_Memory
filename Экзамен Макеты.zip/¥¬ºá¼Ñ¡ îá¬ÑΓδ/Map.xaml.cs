﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Экзамен_Макеты
{
    /// <summary>
    /// Логика взаимодействия для Map.xaml
    /// </summary>
    public partial class Map : Window
    {
        private List<Button> _openCards = new List<Button>();
       
        public Map(int CountCard)
        {
            InitializeComponent();
            //CreateMap(CountCard);
        }
        private void CreateMap(int num)
        {
            for (int i = 0; i < num; i++)
            {
                var button = new Button
                {
                    Content = "?",
                    FontSize = 20,
                };
                //button.Click += CardClick;
                Gridgame.Children.Add(button);
            }
        }
    }
}
